create
    definer = root@localhost procedure sp_delete_type(IN typeId bigint)
BEGIN
    UPDATE book
    SET type_id = NULL
    WHERE type_id = typeId;

    DELETE FROM type WHERE id = typeId;
END;

